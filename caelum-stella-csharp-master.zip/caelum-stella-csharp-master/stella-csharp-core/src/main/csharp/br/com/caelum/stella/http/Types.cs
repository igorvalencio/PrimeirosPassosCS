﻿namespace Caelum.Stella.CSharp.Http
{
    internal class OutputType
    {
        public static string Json = "json";
        public static string Xml = "xml";
        public static string Piped = "piped";
        public static string Querty = "querty";
    }
}
