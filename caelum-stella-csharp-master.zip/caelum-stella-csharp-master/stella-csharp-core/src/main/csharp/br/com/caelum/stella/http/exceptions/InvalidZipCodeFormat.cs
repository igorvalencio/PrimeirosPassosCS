﻿using System;

namespace Caelum.Stella.CSharp.Http.Exceptions
{
    public class InvalidZipCodeFormat : ArgumentException { }
}
