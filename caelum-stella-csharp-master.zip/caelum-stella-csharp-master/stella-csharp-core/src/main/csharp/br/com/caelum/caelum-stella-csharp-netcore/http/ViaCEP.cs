﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CaelumStellaCSharpNetcore.http
{
    class ViaCEP
    {
        public ViaCEP()
        {
            HttpContext
        }
    }
}
