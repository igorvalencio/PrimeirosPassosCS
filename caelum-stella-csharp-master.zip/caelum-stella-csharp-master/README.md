# Caelum Stella C#

Alguns processos são comuns e recorrentes em sistemas voltados para o público brasileiro. O Stella C# vai te auxiliar nesse caso, oferecendo uma API simples para validação e formatação de CPF, CNPJ e outros cadastros comuns no Brasil.
